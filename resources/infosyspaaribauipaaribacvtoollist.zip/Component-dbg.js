sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("infosys.pa.ariba.uipaaribacvtoollist.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);